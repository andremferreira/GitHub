angular.module('primeiraApp', [
  'ui.router',
  'ngAnimate',
  'toastr'
])
