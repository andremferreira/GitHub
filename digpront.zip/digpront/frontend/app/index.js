angular.module('digPront', [
    'ui.router',
    'ngAnimate',
    'toastr'
  ])