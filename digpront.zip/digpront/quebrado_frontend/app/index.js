angular.module('digitalProntuario', [
    'ui.router',
    'ui.mask',
    'ngAnimate',
    'toastr',
    'ngMask'
])